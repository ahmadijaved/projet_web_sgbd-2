/**
 *
 * @author ahmadi
 */


package be.isl.ue.entity;


public interface Entity {
    //methods
    public Integer getId();
    public void setId(Integer id);
}

